#ifndef __AL_EDGE__
#define __AL_EDGE__

typedef struct _edge
{
	int v1;
	int v2;
	int weight;   // ����ġ
} Edge;

#endif