#ifndef __EMPLOYEE_H__
#define __EMPLOYEE_H__

typedef struct _Employee
{
	int empNum;      // ���
	char name[30];    // �̸�
} Employee;

#endif